package com.rest.billing.billingApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BillingAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
