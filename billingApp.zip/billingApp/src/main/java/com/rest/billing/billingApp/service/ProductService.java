package com.rest.billing.billingApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.billing.billingApp.entity.Product;
import com.rest.billing.billingApp.repository.ProductRepository;

@Service

public class ProductService {
	@Autowired
	private ProductRepository prepo;
	
	public List<Product> listAll(){
		return prepo.findAll();
	}
	
	public String getbill(Integer pcode, int qty)
	{
		Product p=null;
		
		Optional<Product> product=prepo.findById(pcode);
		
		if(qty<1)
			return "invalid quantity";
		if(pcode>9999 || pcode<1000)
			return "invalid product code";
		
		if(product.isPresent()) {
			p=product.get();
						
			double totalamt;
			totalamt=p.getPrice()*qty;
						
			//String newLine = System.getProperty("line.separator");
			return "Product name: "+p.getPname()+" || "
					+ "Product category: "+p.getPdesc()+" || "
					+"Product price (Rs.): "+p.getPrice()+" || "
					+"Quantity: "+qty+" || "
					+"Line total (Rs.): "+totalamt;}
		else { 
			p=new Product();
			return "Sorry! The product code "+pcode+" is not available";}		
		
	}


}
