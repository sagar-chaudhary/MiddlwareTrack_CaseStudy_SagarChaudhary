package com.rest.billing.billingApp.entity;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Product {
	
	private Integer pcode;
	private String pname;
	private String pdesc;
	private double price;
	
	public Product() {}

	public Product(int pcode, String pname, String pdesc, double price) {
		super();
		this.pcode = pcode;
		this.pname = pname;
		this.pdesc = pdesc;
		this.price = price;
	}

	@Id
	public int getPcode() {
		return pcode;
	}

	public void setPcode(int pcode) {
		this.pcode = pcode;
	}

	public String getPname() {
		return pname;
	}

	public void setPname(String pname) {
		this.pname = pname;
	}

	public String getPdesc() {
		return pdesc;
	}

	public void setPdesc(String pdesc) {
		this.pdesc = pdesc;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Product [pcode=" + pcode + ", pname=" + pname + ", pdesc=" + pdesc + ", price=" + price + "]\n";
	}
	
	
	

}
