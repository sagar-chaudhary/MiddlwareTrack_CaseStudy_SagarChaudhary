package com.rest.billing.billingApp.restController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rest.billing.billingApp.entity.Product;
import com.rest.billing.billingApp.service.ProductService;


@RestController
@EnableAutoConfiguration
@RequestMapping("/products")
public class ProductRestController {
	
	@Autowired
	private ProductService service;
	
	@RequestMapping(path="/products")
	public List<Product> listProduct(){
		return service.listAll();
	}
	
	@RequestMapping(path="/{pcode}/{qty}")
	public String gettotal(@PathVariable("pcode")Integer pcode,@PathVariable("qty")int qty) {
		return service.getbill(pcode,qty);
	}
	

}
