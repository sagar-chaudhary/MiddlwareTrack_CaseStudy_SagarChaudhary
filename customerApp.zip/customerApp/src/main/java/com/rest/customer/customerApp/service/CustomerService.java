package com.rest.customer.customerApp.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.customer.customerApp.entity.Customer;
import com.rest.customer.customerApp.repository.CustomerRepository;


@Service

public class CustomerService {
	
	@Autowired
	private CustomerRepository crepo;
	
	public List<Customer> listAll(){
		return crepo.findAll();
	}
	
	
	public String getCustomer(String mobileno)
	{
		System.out.println("In service layer");
		Customer c=null;
		
		Optional<Customer> customer=crepo.findById(mobileno);
		
		if(customer.isPresent()) {
			c=customer.get();
			return "your current balance is Rs."+c.getBalance();}
		else { 
			c=new Customer();
			return "Given Account Id Does Not Exist";}			
		
	}
	
	public String recharge(String mobileno, double rechargeamt)
	{
		Customer c=null;
		
		Optional<Customer> customer=crepo.findById(mobileno);
		
		if(customer.isPresent()) {
			c=customer.get();
			c.setBalance(c.getBalance()+rechargeamt);
			Customer rcustomer=crepo.save(c);
			
			return "Your account recharged successfully\n"
					+ "Hello "+c.getCname()+", Available Balance is "+c.getBalance();}
		else { 
			c=new Customer();
			return "Cannot recharge account as given mobile no. does not exist";}		
		
	}
}
