package com.rest.customer.customerApp.restController;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PathVariable;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rest.customer.customerApp.entity.Customer;
import com.rest.customer.customerApp.service.CustomerService;

@RestController
@EnableAutoConfiguration
@RequestMapping("/customers")
public class CustomerRestController {
	
	@Autowired
	private CustomerService service;
	
	@RequestMapping("/customers")
	public List<Customer> listCustomer(){
		return service.listAll();
	}
	
	@RequestMapping(path="/{mobileno}")
	public String getCustomer(@PathVariable("mobileno")String mobileno) {
		return service.getCustomer(mobileno);		
	}
	
	@RequestMapping(path="/{mobileno}/{rechargeamt}")
	public String rechargeblnc(@PathVariable("mobileno")String mobileno,@PathVariable("rechargeamt")double rechargeamt) {
		return service.recharge(mobileno,rechargeamt);		
	}

}
