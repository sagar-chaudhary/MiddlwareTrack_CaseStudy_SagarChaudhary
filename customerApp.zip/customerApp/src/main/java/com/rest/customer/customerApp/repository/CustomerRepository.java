package com.rest.customer.customerApp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.rest.customer.customerApp.entity.Customer;

public interface CustomerRepository extends JpaRepository<Customer, String>{

}
