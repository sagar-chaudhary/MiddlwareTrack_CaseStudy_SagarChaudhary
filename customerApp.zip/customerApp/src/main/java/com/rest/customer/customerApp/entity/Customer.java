package com.rest.customer.customerApp.entity;

import javax.persistence.Entity;
import javax.persistence.Id;



@Entity
public class Customer {
	
	private int cid;
	private String cname;
	private String mobileno;
	private double balance;
	
	public Customer() {}
	public Customer(int cid, String cname, String mobileno, double balance) {
		super();
		this.cid = cid;
		this.cname = cname;
		this.mobileno = mobileno;
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Customer [cid=" + cid + ", cname=" + cname + ", mobileno=" + mobileno + ", balance=" + balance + "]\n";
	}
	
	
	public int getCid() {
		return cid;
	}

	public void setCid(int cid) {
		this.cid = cid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}
	
	@Id
	public String getMobileno() {
		return mobileno;
	}

	public void setMobileno(String mobileno) {
		this.mobileno = mobileno;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}
	
		

}
